import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Random;

abstract class Character {
    private String name;
    private int health;
    private int armor;

    public Character(String name, int health, int armor) {
        this.name = name;
        this.health = health;
        this.armor = armor;
    }

    public String getName() {
        return name;
    }

    public void setArmor(int armor) {
        this.armor = armor;
    }

    public int getHealth() {
        return health;
    }

    public int getArmor() {
        return armor;
    }

    public void takeDamage(int damage) {
        int effectiveDamage = Math.max(0, damage - armor);
        health = Math.max(0, health - effectiveDamage);
    }

    public abstract int attack(Character opponent);
}

class Hero extends Character {
    public Hero(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        Random random = new Random();
        int diceRoll1 = random.nextInt(101);
        int diceRoll2 = random.nextInt(101);
        int offensivePower = Math.max(diceRoll1, diceRoll2);

        // Implement attack modifiers for specific hero types
        if (this instanceof Elf) {
            // Elves hate Orcs, increase offensive power by 10 against Orcs
            if (opponent instanceof Orc) {
                offensivePower += 10;
            }
        } else if (this instanceof Hobbit) {
            // Hobbits fear Trolls, decrease offensive power by 5 against Trolls
            if (opponent instanceof Troll) {
                offensivePower -= 5;
            }
        }

        return offensivePower;
    }
}
class Hobbit extends Hero {
    public Hobbit(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        Random random = new Random();
        int diceRoll1 = random.nextInt(101);
        int diceRoll2 = random.nextInt(101);
        int offensivePower = Math.max(diceRoll1, diceRoll2);

        // Implement attack modifiers for specific hero types
        if (opponent instanceof Troll) {
            // Hobbits fear Trolls, decrease offensive power by 5 against Trolls
            offensivePower -= 5;
        }

        return offensivePower;
    }
}

class Beast extends Character {
    public Beast(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        Random random = new Random();
        return random.nextInt(91);
    }
}

class Elf extends Hero {
    public Elf(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Dwarf extends Hero {
    public Dwarf(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Human extends Hero {
    public Human(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Orc extends Beast {
    public Orc(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        // Orcs possess immense strength, opponent's armor level reduced by 10%
        int opponentArmor = opponent.getArmor();
        opponent.setArmor((int) (opponentArmor * 0.9));

        return super.attack(opponent);
    }
}

class Troll extends Beast {
    public Troll(String name, int health, int armor) {
        super(name, health, armor);
    }
}


public class Game {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of turns: ");
        int numTurns = scanner.nextInt();
        scanner.nextLine();

        List<Hero> heroes = new ArrayList<>();
        List<Beast> beasts = new ArrayList<>();

        System.out.print("Enter the number of heroes: ");
        int numHeroes = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numHeroes; i++) {
            System.out.println("Enter details for Hero " + (i + 1) + ":");
            System.out.print("Name: ");
            String heroName = scanner.nextLine();

            System.out.print("Health: ");
            int heroHealth = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Armor: ");
            int heroArmor = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Hero type (1 - Elf, 2 - Dwarf, 3 - Human): ");
            int heroType = scanner.nextInt();
            scanner.nextLine();

            Hero hero;
            if (heroType == 1) {
                hero = new Elf(heroName, heroHealth, heroArmor);
            } else if (heroType == 2) {
                hero = new Dwarf(heroName, heroHealth, heroArmor);
            } else if (heroType == 3) {
                hero = new Human(heroName, heroHealth, heroArmor);
            } else {
                System.out.println("Invalid hero type. Skipping hero...");
                continue;
            }

            heroes.add(hero);
        }

        System.out.print("Enter the number of beasts: ");
        int numBeasts = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numBeasts; i++) {
            System.out.println("Enter details for Beast " + (i + 1) + ":");
            System.out.print("Name: ");
            String beastName = scanner.nextLine();

            System.out.print("Health: ");
            int beastHealth = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Armor: ");
            int beastArmor = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Beast type (1 - Orc, 2 - Troll): ");
            int beastType = scanner.nextInt();
            scanner.nextLine();

            Beast beast;
            if (beastType == 1) {
                beast = new Orc(beastName, beastHealth, beastArmor);
            } else if (beastType == 2) {
                beast = new Troll(beastName, beastHealth, beastArmor);
            } else {
                System.out.println("Invalid beast type. Skipping beast...");
                continue;
            }

            beasts.add(beast);
        }

        for (int turn = 1; turn <= numTurns; turn++) {
            System.out.println("Turn " + turn + ":");

            for (int i = 0; i < heroes.size(); i++) {
                Hero hero = heroes.get(i);
                Beast beast = beasts.get(i % beasts.size());

                System.out.println("Fight between " + hero.getName() + " (Health=" + hero.getHealth() +
                        " Armor=" + hero.getArmor() + ") and " + beast.getName() + " (Health=" +
                        beast.getHealth() + " Armor=" + beast.getArmor() + ")");

                int heroAttackPower = hero.attack(beast);
                int beastAttackPower = beast.attack(hero);

                if (heroAttackPower > beast.getArmor()) {
                    int damageToBeast = heroAttackPower - beast.getArmor();
                    beast.takeDamage(damageToBeast);
                    System.out.println(hero.getName() + " draws " + heroAttackPower +
                            " and deals " + damageToBeast + " damage to " + beast.getName());
                } else {
                    System.out.println(hero.getName() + " draws " + heroAttackPower +
                            " but fails to penetrate " + beast.getName() + "'s armor");
                }

                if (beastAttackPower > hero.getArmor()) {
                    int damageToHero = beastAttackPower - hero.getArmor();
                    hero.takeDamage(damageToHero);
                    System.out.println(beast.getName() + " draws " + beastAttackPower +
                            " and deals " + damageToHero + " damage to " + hero.getName());
                } else {
                    System.out.println(beast.getName() + " draws " + beastAttackPower +
                            " but fails to penetrate " + hero.getName() + "'s armor");
                }

                System.out.println(hero.getName() + " (Health=" + hero.getHealth() +
                        " Armor=" + hero.getArmor() + ")");
                System.out.println(beast.getName() + " (Health=" + beast.getHealth() +
                        " Armor=" + beast.getArmor() + ")");

                System.out.println(); // Empty line for readability
            }

            // Remove defeated characters
            heroes.removeIf(hero -> hero.getHealth() <= 0);
            beasts.removeIf(beast -> beast.getHealth() <= 0);

            if (heroes.isEmpty() || beasts.isEmpty()) {
                System.out.println("Battle finished!");
                break;
            }
        }

        // Determine the winner
        if (heroes.isEmpty() && !beasts.isEmpty()) {
            System.out.println("Beasts win the battle!");
        } else if (!heroes.isEmpty() && beasts.isEmpty()) {
            System.out.println("Heroes win the battle!");
        } else {
            System.out.println("It's a draw!");
        }
    }
}



