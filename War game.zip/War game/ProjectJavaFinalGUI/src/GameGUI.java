import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

abstract class Character {
    private String name;
    private int health;
    private int armor;

    public Character(String name, int health, int armor) {
        this.name = name;
        this.health = health;
        this.armor = armor;
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public int getArmor() {
        return armor;
    }

    public void takeDamage(int damage) {
        int effectiveDamage = Math.max(0, damage - armor);
        health = Math.max(0, health - effectiveDamage);
    }

    public abstract int attack(Character opponent);
}

class Hero extends Character {
    public Hero(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        Random random = new Random();
        int diceRoll1 = random.nextInt(101);
        int diceRoll2 = random.nextInt(101);
        int offensivePower = Math.max(diceRoll1, diceRoll2);

        // Implement attack modifiers for specific hero types
        if (this instanceof Elf) {
            // Elves hate Orcs, increase offensive power by 10 against Orcs
            if (opponent instanceof Orc) {
                offensivePower += 10;
            }
        } else if (this instanceof Hobbit) {
            // Hobbits fear Trolls, decrease offensive power by 5 against Trolls
            if (opponent instanceof Troll) {
                offensivePower -= 5;
            }
        }

        return offensivePower;
    }
}

class Hobbit extends Hero {
    public Hobbit(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        Random random = new Random();
        int diceRoll1 = random.nextInt(101);
        int diceRoll2 = random.nextInt(101);
        int offensivePower = Math.max(diceRoll1, diceRoll2);

        // Implement attack modifiers for specific hero types
        if (opponent instanceof Troll) {
            // Hobbits fear Trolls, decrease offensive power by 5 against Trolls
            offensivePower -= 5;
        }

        return offensivePower;
    }
}

class Beast extends Character {
    public Beast(String name, int health, int armor) {
        super(name, health, armor);
    }

    @Override
    public int attack(Character opponent) {
        Random random = new Random();
        int diceRoll = random.nextInt(91);
        return diceRoll;
    }
}

class Elf extends Hero {
    public Elf(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Dwarf extends Hero {
    public Dwarf(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Human extends Hero {
    public Human(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Orc extends Beast {
    public Orc(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class Troll extends Beast {
    public Troll(String name, int health, int armor) {
        super(name, health, armor);
    }
}

class GameGUI extends JPanel {
    private JTextArea battleLogTextArea;
    private JTextField numTurnsTextField;
    private JTextField numHeroesTextField;
    private JTextField numBeastsTextField;
    private JButton startButton;

    public GameGUI() {
        setPreferredSize(new Dimension(500, 500));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        battleLogTextArea = new JTextArea();
        battleLogTextArea.setEditable(false);
        battleLogTextArea.setPreferredSize(new Dimension(500, 400));
        JScrollPane scrollPane = new JScrollPane(battleLogTextArea);
        add(scrollPane);

        JPanel inputPanel = new JPanel();
        inputPanel.setPreferredSize(new Dimension(500, 100));
        inputPanel.setLayout(new FlowLayout());

        numTurnsTextField = new JTextField(10);
        numHeroesTextField = new JTextField(10);
        numBeastsTextField = new JTextField(10);
        JLabel numTurnsLabel = new JLabel("Number of Turns:");
        JLabel numHeroesLabel = new JLabel("Number of Heroes:");
        JLabel numBeastsLabel = new JLabel("Number of Beasts:");

        startButton = new JButton("Start Battle");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBattle();
            }
        });

        inputPanel.add(numTurnsLabel);
        inputPanel.add(numTurnsTextField);
        inputPanel.add(numHeroesLabel);
        inputPanel.add(numHeroesTextField);
        inputPanel.add(numBeastsLabel);
        inputPanel.add(numBeastsTextField);
        inputPanel.add(startButton);

        add(inputPanel);
    }

    private void startBattle() {
        int numTurns = Integer.parseInt(numTurnsTextField.getText());
        int numHeroes = Integer.parseInt(numHeroesTextField.getText());
        int numBeasts = Integer.parseInt(numBeastsTextField.getText());

        List<Hero> heroes = new ArrayList<>();
        List<Beast> beasts = new ArrayList<>();

        for (int i = 1; i <= numHeroes; i++) {
            String heroName = JOptionPane.showInputDialog("Enter the name of Hero " + i + ":");
            int heroHealth = Integer.parseInt(JOptionPane.showInputDialog("Enter the health of Hero " + i + ":"));
            int heroArmor = Integer.parseInt(JOptionPane.showInputDialog("Enter the armor of Hero " + i + ":"));

            // Prompt for hero type (Elf, Dwarf, Human, etc.)
            String[] heroTypes = { "Elf", "Dwarf", "Human" };
            String selectedHeroType = (String) JOptionPane.showInputDialog(
                    null,
                    "Select the type of Hero " + i + ":",
                    "Hero Type",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    heroTypes,
                    heroTypes[0]
            );

            Hero hero;
            switch (selectedHeroType) {
                case "Elf":
                    hero = new Elf(heroName, heroHealth, heroArmor);
                    break;
                case "Dwarf":
                    hero = new Dwarf(heroName, heroHealth, heroArmor);
                    break;
                case "Human":
                    hero = new Human(heroName, heroHealth, heroArmor);
                    break;
                default:
                    hero = new Hero(heroName, heroHealth, heroArmor);
                    break;
            }

            heroes.add(hero);
        }
        for (int i = 1; i <= numBeasts; i++) {
            String beastName = JOptionPane.showInputDialog("Enter the name of Beast " + i + ":");
            int beastHealth = Integer.parseInt(JOptionPane.showInputDialog("Enter the health of Beast " + i + ":"));
            int beastArmor = Integer.parseInt(JOptionPane.showInputDialog("Enter the armor of Beast " + i + ":"));

            // Prompt for beast type (Orc, Troll, etc.)
            String[] beastTypes = { "Orc", "Troll" };
            String selectedBeastType = (String) JOptionPane.showInputDialog(
                    null,
                    "Select the type of Beast " + i + ":",
                    "Beast Type",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    beastTypes,
                    beastTypes[0]
            );

            Beast beast;
            switch (selectedBeastType) {
                case "Orc":
                    beast = new Orc(beastName, beastHealth, beastArmor);
                    break;
                case "Troll":
                    beast = new Troll(beastName, beastHealth, beastArmor);
                    break;
                default:
                    beast = new Beast(beastName, beastHealth, beastArmor);
                    break;
            }

            beasts.add(beast);
        }

        for (int turn = 1; turn <= numTurns; turn++) {
            battleLogTextArea.append("Turn " + turn + ":\n");

            for (int i = 0; i < heroes.size(); i++) {
                Hero hero = heroes.get(i);
                Beast beast = beasts.get(i);

                battleLogTextArea.append("Fight between " + hero.getName() + " (Health=" + hero.getHealth() +
                        " Armor=" + hero.getArmor() + ") and " + beast.getName() + " (Health=" +
                        beast.getHealth() + " Armor=" + beast.getArmor() + ")\n");

                int heroAttack = hero.attack(beast);
                int beastAttack = beast.attack(hero);

                if (heroAttack > beast.getArmor()) {
                    int damage = heroAttack - beast.getArmor();
                    beast.takeDamage(damage);
                    battleLogTextArea.append(hero.getName() + " draws " + heroAttack +
                            " and deals " + damage + " damage to " + beast.getName() + "\n");
                } else {
                    battleLogTextArea.append(hero.getName() + " draws " + heroAttack +
                            " but fails to damage " + beast.getName() + "\n");
                }

                if (beast.getHealth() > 0) {
                    if (beastAttack > hero.getArmor()) {
                        int damage = beastAttack - hero.getArmor();
                        hero.takeDamage(damage);
                        battleLogTextArea.append(beast.getName() + " draws " + beastAttack +
                                " and deals " + damage + " damage to " + hero.getName() + "\n");
                    } else {
                        battleLogTextArea.append(beast.getName() + " draws " + beastAttack +
                                " but fails to damage " + hero.getName() + "\n");
                    }
                }

                if (hero.getHealth() <= 0) {
                    battleLogTextArea.append(hero.getName() + " has been defeated!\n");
                }

                if (beast.getHealth() <= 0) {
                    battleLogTextArea.append(beast.getName() + " has been defeated!\n");
                }
            }
        }

        // Check the result of the battle
        int numHeroesDefeated = 0;
        int numBeastsDefeated = 0;

        for (Hero hero : heroes) {
            if (hero.getHealth() <= 0) {
                numHeroesDefeated++;
            }
        }

        for (Beast beast : beasts) {
            if (beast.getHealth() <= 0) {
                numBeastsDefeated++;
            }
        }

        if (numHeroesDefeated == numHeroes && numBeastsDefeated == numBeasts) {
            battleLogTextArea.append("The battle ends in a draw!\n");
        } else if (numHeroesDefeated == numHeroes) {
            battleLogTextArea.append("The beasts win the battle!\n");
        } else if (numBeastsDefeated == numBeasts) {
            battleLogTextArea.append("The heroes win the battle!\n");
        }

        startButton.setEnabled(false);


}


            private List<Hero> createHeroes(int numHeroes) {
        List<Hero> heroes = new ArrayList<>();

        // Add your hero creation logic here
        // Example:
        for (int i = 1; i <= numHeroes; i++) {
            Hero hero = new Hero("Hero " + i, 100, 10);
            heroes.add(hero);
        }

        return heroes;
    }

    private List<Beast> createBeasts(int numBeasts) {
        List<Beast> beasts = new ArrayList<>();
        for (int i = 1; i <= numBeasts; i++) {
            Beast beast = new Beast("Beast " + i, 100, 5);
            beasts.add(beast);
        }

        return beasts;
    }

    private void createAndShowGUI() {
        JFrame frame = new JFrame("Battle Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(new BorderLayout());

        battleLogTextArea = new JTextArea();
        battleLogTextArea.setEditable(false);
        battleLogTextArea.setBackground(Color.WHITE); // Set background color to white
        battleLogTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12)); // Set a monospaced font for better alignment
        JScrollPane scrollPane = new JScrollPane(battleLogTextArea);
        scrollPane.setPreferredSize(new Dimension(500, 400)); // Set preferred size for the scroll pane
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER); // Add scroll pane to the content pane

        JPanel inputPanel = new JPanel();
        inputPanel.setPreferredSize(new Dimension(500, 100)); // Adjust dimensions of the input panel
        inputPanel.setLayout(new FlowLayout());

        numTurnsTextField = new JTextField(10);
        numHeroesTextField = new JTextField(10);
        numBeastsTextField = new JTextField(10);
        JLabel numTurnsLabel = new JLabel("Number of Turns:");
        JLabel numHeroesLabel = new JLabel("Number of Heroes:");
        JLabel numBeastsLabel = new JLabel("Number of Beasts:");

        startButton = new JButton("Start Battle");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBattle();
            }
        });

        inputPanel.add(numTurnsLabel);
        inputPanel.add(numTurnsTextField);
        inputPanel.add(numHeroesLabel);
        inputPanel.add(numHeroesTextField);
        inputPanel.add(numBeastsLabel);
        inputPanel.add(numBeastsTextField);
        inputPanel.add(startButton);

        frame.add(inputPanel, BorderLayout.SOUTH);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                GameGUI game = new GameGUI();
                game.createAndShowGUI();
            }
        });
    }
}
